<h3 style="text-align: center;">CLUB EVENTS</h3>
<table class="table table-striped table-bordered clubEvents" id="eventprnt" style="text-transform: capitalize;">
        <thead class="thead-Dark">
            <tr  style="text-align: center">

                <th>Organization</th>
                <th>League</th>
                <th>Event</th>
                <th>Age Group</th>
                <th>Gender</th>
                <th>Team Name</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>



        @foreach($group_registations as $group_registation)
        @if($group_registation->club_id ==Auth::user()->club_id)
        
            <tr>    
                <td>{{ $group_registation->organization->name }}</td>

                <td>{{ $group_registation->league->name }}</td>



                <td>{{$group_registation->ageGroupGender->ageGroupEvent->Event->mainEvent->name}}</td>

                
                <td>
                @foreach ($group_registation->teams as $team)
                
                {{ $team->ageGroup->name }}
                @endforeach</td>

                
                

                <td>
                @foreach ($group_registation->teams as $team)
                {{ $team->gender->name }}
                @endforeach</td>

                <td>
                @foreach ($group_registation->teams as $team)
                    {{ $team->name }}
                    @endforeach
                </td>

                <!-- <td>
                {{ $group_registation->status }}</td> -->

                @if($group_registation->ageGroupGender->status==2)
                                <td>
                                  Not Started

                                </td>
                                @elseif($group_registation->ageGroupGender->status==0)
                                <td> On Going 
                                </td>
                                @else
                                <td> Finished
                                </td>
                                @endif
            </tr>
            @endif
        @endforeach
                

        </tbody>
    </table>