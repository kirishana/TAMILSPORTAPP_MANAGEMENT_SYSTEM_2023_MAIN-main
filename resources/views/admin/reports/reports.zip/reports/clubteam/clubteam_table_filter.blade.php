

<div class="row" id="club-t">

<h3 style="text-align: center;">CLUB TEAMS</h3>

    <table class="table table-striped table-bordered club-t" id="c-team" style="text-transform: capitalize;">
        <thead class="thead-Dark">
            <tr  style="text-align: center">

                <th>Club Team Name</th>
                <th>Members</th>
                <th>Age Group</th>
                <th>Gender</th>
                

            </tr>
        </thead>
        <tbody>

                @foreach($teams as $team)
            <tr>
                <td>{{$team->name}}</td>
                
                <td>
                @foreach ($team->users as $user)
                {{$user->first_name}}  {{$user->last_name}}<br>
                 @endforeach
                </td>

                <td>
                   {{ $team->ageGroup->name }}
                    </td>
                    <td>
                      {{ $team->gender_id==1?'Male':'Female'}}
                        </td>
                
            </tr>
            @endforeach
            

        </tbody>
    </table>
    
</div>
<script type="text/php">
    if (isset($pdf)) {
        $x = 250;
        $y = 820;
        $text = "Page {PAGE_NUM} of {PAGE_COUNT}";
        $font = null;
        $size = 14;
        $color = array(0,0,0);
        $word_space = 0.0;  //  default
        $char_space = 0.0;  //  default
        $angle = 0.0;   //  default
        $pdf->page_text($x, $y, $text, $font, $size, $color, $word_space, $char_space, $angle);
    }
</script>

 


