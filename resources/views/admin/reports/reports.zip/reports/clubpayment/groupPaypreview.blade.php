<style type="text/css">
    .table {
        width: 100%;
        border-collapse: collapse;
        text-transform: capitalize;

    }

    table td,
    table th {
        border: 1px solid black;
        text-align: center;
    }

    table tr,
    table td {
        padding: 5px;
        text-align: left;
    }
  .thead-Dark th {
 
 color: #fffffc;
 /* opacity: 0.8; */
 background-color: #3A3B3C;
 text-transform: uppercase;
 font-size: 12px;

 /* border-color: #792700; */

}
</style>
<div class="row" id="G-print">

    <table class="table table-striped table-bordered  anton" id="clubpdf">
        <thead class="thead-Dark">
            <tr>
                <th>Events</th>
                <th>Transaction ID</th>
                <th>Payment Method</th>
                <th>Status</th>
                <th>Paid Amount</th>
            </tr>
        </thead>
        <tbody class="">
            @foreach($groupregistration as $regist)
           

                <tr> 
                <td>
                        {{ $regist->event->mainEvent->name }}
                    </td>
                    <td>
                        {{ $regist->trans_id }}
                    </td>
                    @if($regist->payment_method == 0)
                           <td>Vipps</td> 
                        @else
                            <td> Bank</td>
                        @endif

                    @if($regist->status== 2)
                                
                                    <td>approved</td>
                                
                                @else
                                    <td>pending</td>
                                
                                  @endif  

                    <td>{{$regist->organization->country->currency->currency_iso_code}}.{{ $regist->totalfee }}
                    </td>
                </tr>

           
           
            @endforeach
        </tbody>
    </table>
   
    <section class="content-footer">
        <div class="col-md-1">
            @if($setting){!! html_entity_decode($setting->footer) !!}@endif


        </div>
    </section>
</div>
<script src="//cdn.ckeditor.com/4.14.0/standard/ckeditor.js"></script>
<script>
    $(document).ready(function() {
        $('.ckeditor').ckeditor();
    });
</script>