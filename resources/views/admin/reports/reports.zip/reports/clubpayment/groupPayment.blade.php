<div class="col-md-12">

    <table class="table table-striped table-bordered  anton" id="table10" style="text-transform: capitalize;">
        <thead class="thead-Dark">
            <tr>
                <th>Events</th>
                <th>Transaction ID</th>
                <th>Payment Method</th>
                <th>Status</th>
                <th>Paid Amount</th>
            </tr>
        </thead>
        <tbody class="">
            @foreach($groupregistration as $regist)          
                <tr>           
                    <td>
                        {{ $regist->event->mainEvent->name }}
                    </td>
                    <td>
                        {{ $regist->trans_id }}
                    </td>
                    @if($regist->payment_method == 0)
                           <td>Vipps</td> 
                        @else
                            <td> Bank</td>
                        @endif
                    @if($regist->status== 2)
                                
                                    <td>approved</td>
                                
                                @else
                                    <td>pending</td>
                                
                                  @endif  

                    <td>{{$regist->organization->country->currency->currency_iso_code}}.{{ $regist->totalfee }}
                    </td>
                </tr>          
            @endforeach
        </tbody>
</table>
