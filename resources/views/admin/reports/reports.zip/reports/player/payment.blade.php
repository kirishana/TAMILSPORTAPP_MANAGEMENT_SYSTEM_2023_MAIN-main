@extends('admin/layouts/default')

{{-- Page title --}}
@section('title')
Participants
@parent
@stop

    {{-- page level styles --}}
    @section('header_styles')
    <style>
        .mt-100 {
            margin-top: 100px
        }

        /* body {
        background: #00B4DB;
        background: -webkit-linear-gradient(to right, #0083B0, #00B4DB);
        background: linear-gradient(to right, #0083B0, #00B4DB);
        color: #514B64;
        min-height: 100vh
    } */

    </style>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/bbbootstrap/libraries@main/choices.min.css">
    <script src="https://cdn.jsdelivr.net/gh/bbbootstrap/libraries@main/choices.min.js"></script>

    @stop

        {{-- Page content --}}
        @section('content')

        <section class="content-header">
            <!--section starts-->
            <h1>Payment </h1>
            <ol class="breadcrumb">
                <li>
                    <a href="">
                        <i class="material-icons breadmaterial">home</i>

                        Dashboard
                    </a>
                </li>
                <li>
                    <a href="#">Reports</a>
                </li>
                <li class="active"> Payment</li>
            </ol>
        </section>
        <!--section ends-->
        <section class="content">
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-primary filterable">
                        <div class="panel-heading">
                            <h3 class="panel-title">
                                Payment
                            </h3>
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-md-2">

                                    <select id="organization" class="form-control multiselect organization"
                                        placeholder="Select Organization" multiple>
                                        <option value="duplicate">all</option>

                                        @foreach($organizations as $organization)
                                            <option value={{ $organization->id }}>{{ $organization->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="col-md-2">
                                    <select id="league" class="form-control multiselect league"
                                        placeholder="Select League" multiple>
                                        <option value="duplicate3">all</option>
                                        @foreach($leagues as $league)
                                            <option value={{ $league->id }}>{{ $league->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="col-md-3">

                                    <select id="status" class="form-control multiselect status"
                                        placeholder="Select Status" multiple>
                                        <option value="duplicate2">All</option>

                                        <option value='2'>Approved</option>
                                        <option value='1'>Pending</option>

                                    </select>
                                </div>

                                <div class="col-md-2">
                                    <input id="amount" data-name="amount" name="amount[]" placeholder=" Amount&nbsp;in&nbsp;{{$currency->country->currency->currency_iso_code
}} "
                                        type="text" style="
width: 100%;
padding: 12px 20px;
margin: 28px 0;
display: inline-block;
border: 1px solid #ccc;
border-radius: 4px;
box-sizing: border-box;
">

                                </div>
                                <div class="col-md-3">
                                    <input id="trans_id" data-name="trans_id" maxlength="11" name="trans_id[]"
                                        placeholder="Transaction ID" type="text" style="
width: 100%;
padding: 12px 20px;
margin: 28px 0;
display: inline-block;
border: 1px solid #ccc;
border-radius: 4px;
box-sizing: border-box;
">

                                </div>



                            </div>
                            <div class="row">
                                <div class="col-md-1 pull-right"
                                    style="margin-top: 35px; display:flex; justify-content:flex-end;">
                                    <a id="btn-play" style="cursor:pointer;margin-right:5px;"><img
                                            src="{{ asset('assets/images/print.png') }}">
                                    </a>
                                    <a href="/pay_play/export" style="margin-right:5px;" target="_blank"> <img
                                            src="{{ asset('assets/images/pdf.png') }}">
                                    </a>

                                    <a href="/pay_play/excel" style="margin-right:5px;"> <img
                                            src="{{ asset('assets/images/excel.png') }}">
                                    </a>
                                </div>
                            </div>
                            <br>
                            <div class="table-responsive">


                                @include('admin.reports.player.pay-filter')

                            </div>


                        </div>
                    </div>
                </div>
            </div>

            <!-- Third Basic Table Ends Here-->
        </section>

        <div style="display:none;">
            @include('admin.reports.player.pay-preview')

        </div>
        <!-- content -->
        @stop

            {{-- page level scripts --}}
            @section('footer_scripts')


            <script src="https://cdnjs.cloudflare.com/ajax/libs/jQuery.print/1.6.2/jQuery.print.min.js"
                integrity="sha512-t3XNbzH2GEXeT9juLjifw/5ejswnjWWMMDxsdCg4+MmvrM+MwqGhxlWeFJ53xN/SBHPDnW0gXYvBx/afZZfGMQ=="
                crossorigin="anonymous" referrerpolicy="no-referrer"></script>
            <script>
                $(document).ready(function () {

                    var multipleCancelButton = new Choices('#organization', {
                        removeItemButton: true,
                        maxItemCount: 10000,
                        searchResultLimit: 10000,
                        renderChoiceLimit: 10000
                    });
                    var multipleCancelButton = new Choices('#status', {
                        removeItemButton: true,
                        maxItemCount: 10000,
                        searchResultLimit: 10000,
                        renderChoiceLimit: 10000
                    });
                    var multipleCancelButton = new Choices('#league', {
                        removeItemButton: true,
                        maxItemCount: 10000,
                        searchResultLimit: 10000,
                        renderChoiceLimit: 10000
                    });

                });
                $("#btn-play").click(function () {
                    $("#print").print();
                });
                var obj = {};
                var trans_id = [];
                var statusData = [];
                var leagueData = [];
                var organizationData = [];
                var amount = [];

                $("#amount").on('keyup', function () {

                    $.each($(".status option:selected").map(function () {

                        statusData.push($(this).val());
                    }));
                    $.each($(".league option:selected").map(function () {

                        leagueData.push($(this).val());
                    }));
                    $.each($(".organization option:selected").map(function () {

                        organizationData.push($(this).val());
                    }));

                    var value = document.getElementById('trans_id').value;
                    trans_id.push(value);
                    var value = document.getElementById('amount').value;
                    amount.push(value);

                    obj['status'] = statusData;
                    obj['organization'] = organizationData;
                    obj['league'] = leagueData;
                    obj['amount'] = amount;
                    obj['trans_id'] = trans_id;
                    var length = statusData.length;
                    var length2 = amount.length;
                    var length3 = trans_id.length;
                    var length4 = organizationData.length;
                    var length5 = leagueData.length;


                    $.ajax({
                        type: 'POST',
                        url: '/paymentplaysearch',
                        data: {
                            "_token": "{{ csrf_token() }}",

                            "obj": obj,
                            "length": length,
                            "length2": length2,
                            "length3": length3,
                            "length4": length4,
                            "length5": length5,
                            'statusData': statusData,
                            'organizationData': organizationData,
                            'leagueData': leagueData,

                        },

                        success: function (response) {
                            $('.play').html(response['html'])
                        }
                    });

                });


                $("#trans_id").on('keyup', function () {

                    $.each($(".status option:selected").map(function () {

                        statusData.push($(this).val());
                    }));
                    $.each($(".league option:selected").map(function () {

                        leagueData.push($(this).val());
                    }));
                    $.each($(".organization option:selected").map(function () {

                        organizationData.push($(this).val());
                    }));

                    var value = document.getElementById('trans_id').value;
                    trans_id.push(value);
                    var value = document.getElementById('amount').value;
                    amount.push(value);

                    obj['status'] = statusData;
                    obj['organization'] = organizationData;
                    obj['league'] = leagueData;
                    obj['amount'] = amount;
                    obj['trans_id'] = trans_id;
                    var length = statusData.length;
                    var length2 = amount.length;
                    var length3 = trans_id.length;
                    var length4 = organizationData.length;
                    var length5 = leagueData.length;


                    $.ajax({
                        type: 'POST',
                        url: '/paymentplaysearch',
                        data: {
                            "_token": "{{ csrf_token() }}",

                            "obj": obj,
                            "length": length,
                            "length2": length2,
                            "length3": length3,
                            "length4": length4,
                            "length5": length5,
                            'statusData': statusData,
                            'organizationData': organizationData,
                            'leagueData': leagueData,

                        },

                        success: function (response) {
                            $('.play').html(response['html'])
                        }
                    });

                });


                $("#status").on('change', function () {

                    $.each($(".status option:selected").map(function () {

                        statusData.push($(this).val());
                    }));
                    $.each($(".league option:selected").map(function () {

                        leagueData.push($(this).val());
                    }));
                    $.each($(".organization option:selected").map(function () {

                        organizationData.push($(this).val());
                    }));

                    var value = document.getElementById('trans_id').value;
                    trans_id.push(value);
                    var value = document.getElementById('amount').value;
                    amount.push(value);

                    obj['status'] = statusData;
                    obj['organization'] = organizationData;
                    obj['league'] = leagueData;
                    obj['amount'] = amount;
                    obj['trans_id'] = trans_id;
                    var length = statusData.length;
                    var length2 = amount.length;
                    var length3 = trans_id.length;
                    var length4 = organizationData.length;
                    var length5 = leagueData.length;


                    $.ajax({
                        type: 'POST',
                        url: '/paymentplaysearch',
                        data: {
                            "_token": "{{ csrf_token() }}",

                            "obj": obj,
                            "length": length,
                            "length2": length2,
                            "length3": length3,
                            "length4": length4,
                            "length5": length5,
                            'statusData': statusData,
                            'organizationData': organizationData,
                            'leagueData': leagueData,

                        },

                        success: function (response) {
                            $('.play').html(response['html'])
                        }
                    });

                });

                $("#organization").on('change', function () {

                    $.each($(".status option:selected").map(function () {

                        statusData.push($(this).val());
                    }));
                    $.each($(".league option:selected").map(function () {

                        leagueData.push($(this).val());
                    }));
                    $.each($(".organization option:selected").map(function () {

                        organizationData.push($(this).val());
                    }));

                    var value = document.getElementById('trans_id').value;
                    trans_id.push(value);
                    var value = document.getElementById('amount').value;
                    amount.push(value);

                    obj['status'] = statusData;
                    obj['organization'] = organizationData;
                    obj['league'] = leagueData;
                    obj['amount'] = amount;
                    obj['trans_id'] = trans_id;
                    var length = statusData.length;
                    var length2 = amount.length;
                    var length3 = trans_id.length;
                    var length4 = organizationData.length;
                    var length5 = leagueData.length;


                    $.ajax({
                        type: 'POST',
                        url: '/paymentplaysearch',
                        data: {
                            "_token": "{{ csrf_token() }}",

                            "obj": obj,
                            "length": length,
                            "length2": length2,
                            "length3": length3,
                            "length4": length4,
                            "length5": length5,
                            'statusData': statusData,
                            'organizationData': organizationData,
                            'leagueData': leagueData,

                        },

                        success: function (response) {
                            $('.play').html(response['html'])
                        }
                    });

                });

                $("#league").on('change', function () {

                    $.each($(".status option:selected").map(function () {

                        statusData.push($(this).val());
                    }));
                    $.each($(".league option:selected").map(function () {

                        leagueData.push($(this).val());
                    }));
                    $.each($(".organization option:selected").map(function () {

                        organizationData.push($(this).val());
                    }));

                    var value = document.getElementById('trans_id').value;
                    trans_id.push(value);
                    var value = document.getElementById('amount').value;
                    amount.push(value);

                    obj['status'] = statusData;
                    obj['organization'] = organizationData;
                    obj['league'] = leagueData;
                    obj['amount'] = amount;
                    obj['trans_id'] = trans_id;
                    var length = statusData.length;
                    var length2 = amount.length;
                    var length3 = trans_id.length;
                    var length4 = organizationData.length;
                    var length5 = leagueData.length;


                    $.ajax({
                        type: 'POST',
                        url: '/paymentplaysearch',
                        data: {
                            "_token": "{{ csrf_token() }}",

                            "obj": obj,
                            "length": length,
                            "length2": length2,
                            "length3": length3,
                            "length4": length4,
                            "length5": length5,
                            'statusData': statusData,
                            'organizationData': organizationData,
                            'leagueData': leagueData,

                        },

                        success: function (response) {
                            $('.play').html(response['html'])
                        }
                    });

                });



                //
                $("#pay-pdf").on('click', function () {
                    $.each($(".status option:selected").map(function () {

                        statusData.push($(this).val());
                    }));
                    $.each($(".league option:selected").map(function () {

                        leagueData.push($(this).val());
                    }));
                    $.each($(".organization option:selected").map(function () {

                        organizationData.push($(this).val());
                    }));
                    var value = document.getElementById('trans_id').value;
                    trans_id.push(value);
                    var value = document.getElementById('amount').value;
                    amount.push(value);


                    obj['status'] = statusData;
                    obj['organization'] = organizationData;
                    obj['league'] = leagueData;
                    obj['amount'] = amount;
                    obj['trans_id'] = trans_id;
                    var length = statusData.length;
                    var length2 = amount.length;
                    var length3 = trans_id.length;
                    var length4 = organizationData.length;
                    var length5 = leagueData.length;

                    $.ajax({
                        type: 'GET',
                        url: '',
                        ContentType: 'application/pdf',
                        data: {
                            "_token": "{{ csrf_token() }}",

                            "obj": obj,
                            "length3": length3,
                            "length": length,
                            "length2": length2,
                            "length4": length4,
                            "length5": length5,
                            'statusData': statusData,
                            'organizationData': organizationData,
                            'leagueData': leagueData,


                        },


                    });
                });

            </script>
            @stop
